package com.multiwin.tiler

import android.content.Context
import android.graphics.Rect
import android.util.DisplayMetrics
import android.view.WindowInsets
import android.view.WindowManager

/** Screen area between status bar / nav bar (any side), in real display pixels, for the current rotation. */
object ScreenArea {
    fun usable(ctx: Context): Rect {
        val wm = ctx.applicationContext.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            val mm = wm.currentWindowMetrics
            val b = mm.bounds
            val ins = mm.windowInsets.getInsetsIgnoringVisibility(WindowInsets.Type.systemBars())
            return Rect(b.left + ins.left, b.top + ins.top, b.right - ins.right, b.bottom - ins.bottom)
        }
        val m = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(m)
        val res = ctx.resources
        fun dimen(name: String): Int {
            val id = res.getIdentifier(name, "dimen", "android")
            return if (id > 0) res.getDimensionPixelSize(id) else 0
        }
        val landscape = m.widthPixels > m.heightPixels
        val nav = dimen(if (landscape) "navigation_bar_width" else "navigation_bar_height")
        return if (landscape) Rect(0, dimen("status_bar_height"), m.widthPixels - nav, m.heightPixels)
        else Rect(0, dimen("status_bar_height"), m.widthPixels, m.heightPixels - nav)
    }
}
