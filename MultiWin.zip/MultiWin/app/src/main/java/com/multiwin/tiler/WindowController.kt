package com.multiwin.tiler

import android.content.Context
import android.content.Intent
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import java.util.concurrent.atomic.AtomicInteger

data class AppItem(val label: String, val pkg: String)

/** One row of the drawer. */
data class SessionEntry(val item: AppItem, val stopped: Boolean, val active: Boolean)

/** Holds the current window session so both the app screen and the drawer can use it. */
object WindowController {
    private val handler = Handler(Looper.getMainLooper())
    private var appCtx: Context? = null

    // Every app of the session, stopped ones included. The first app that is not
    // stopped is the active one; the running apps map to slots in this order.
    private var session = mutableListOf<AppItem>()
    private val stopped = mutableSetOf<String>()
    private var mode: LayoutMode = LayoutMode.BIG_STRIP

    var onLog: ((String) -> Unit)? = null

    /** Bumped on every launch/swap/retile so an older placement thread stops itself. */
    private val generation = AtomicInteger(0)
    private fun isStale(gen: Int) = generation.get() != gen

    private fun running(): List<AppItem> = session.filter { it.pkg !in stopped }

    /** All session apps in order, with their stopped / active state. */
    fun entries(): List<SessionEntry> {
        val activePkg = running().firstOrNull()?.pkg
        return session.map { SessionEntry(it, it.pkg in stopped, it.pkg == activePkg) }
    }

    private fun log(msg: String) { handler.post { onLog?.invoke(msg) } }

    private fun slotsFor(apps: List<AppItem>): List<Rect> {
        val ctx = appCtx ?: return emptyList()
        return Tiler.slotsIn(mode, apps.size, ScreenArea.usable(ctx))
    }

    fun launch(ctx: Context, picked: List<AppItem>, mode: LayoutMode, area: Rect) {
        val app = ctx.applicationContext
        appCtx = app
        val pm = app.packageManager
        this.mode = mode
        stopped.clear()
        session = picked.toMutableList()
        val apps = session.toList()
        val slotSnap = Tiler.slotsIn(mode, apps.size, area)
        val gen = generation.incrementAndGet()
        Thread {
            val sb = StringBuilder()
            apps.forEachIndexed { i, item ->
                if (isStale(gen)) return@Thread
                val comp = pm.getLaunchIntentForPackage(item.pkg)?.component?.flattenToShortString()
                if (comp == null) {
                    sb.appendLine("${item.label}: no launcher activity")
                    return@forEachIndexed
                }
                val out = ShizukuShell.exec("am start -n $comp --windowingMode 5 2>&1")
                sb.appendLine("${item.label}: ${out.lines().lastOrNull { it.isNotBlank() } ?: "started"}")
                Thread.sleep(1300)
                if (i < slotSnap.size) sb.appendLine("  " + place(item.pkg, slotSnap[i]))
            }
            sb.append(settle(apps, slotSnap, gen))
            if (!isStale(gen)) log(sb.toString())
        }.start()
    }

    /**
     * Apps often snap back to their own minimum size / aspect ratio after launch,
     * which makes one window overlap its neighbours. Re-apply bounds a couple of
     * times: small tiles first, the big active window last.
     */
    private fun settle(apps: List<AppItem>, slotSnap: List<Rect>, gen: Int): String {
        val sb = StringBuilder()
        if (apps.isEmpty()) return ""
        val order = (1 until apps.size).toList() + 0
        repeat(3) { pass ->
            Thread.sleep(if (pass == 2) 1500L else 800L)
            for (idx in order) {
                if (isStale(gen)) return sb.toString()
                if (idx >= slotSnap.size) continue
                val res = place(apps[idx].pkg, slotSnap[idx])
                if (pass == 2) sb.appendLine("${apps[idx].label} (settle): $res")
            }
        }
        return sb.toString()
    }

    /** Blocking. Places every app once (small tiles first, active last), then settles. */
    private fun layoutAll(apps: List<AppItem>, slotSnap: List<Rect>, gen: Int): String {
        if (apps.isEmpty()) return ""
        val sb = StringBuilder()
        val order = (1 until apps.size).toList() + 0
        for (idx in order) {
            if (isStale(gen)) return sb.toString()
            if (idx >= slotSnap.size) continue
            sb.appendLine("${apps[idx].label}: " + place(apps[idx].pkg, slotSnap[idx]))
        }
        sb.append(settle(apps, slotSnap, gen))
        return sb.toString()
    }

    /** Re-computes the layout for the current rotation and re-places every running window. */
    fun retile(ctx: Context) {
        if (session.isEmpty()) return
        appCtx = ctx.applicationContext
        val apps = running()
        if (apps.isEmpty()) return
        val slotSnap = slotsFor(apps)
        val gen = generation.incrementAndGet()
        Thread { val r = settle(apps, slotSnap, gen); if (!isStale(gen)) log(r) }.start()
    }

    /** Swaps the given running app with the active app (first running app). */
    fun swapWithActive(pkg: String) {
        val run = running()
        if (run.size < 2) return
        val active = run[0]
        if (pkg == active.pkg || pkg in stopped) return
        val ai = session.indexOfFirst { it.pkg == active.pkg }
        val bi = session.indexOfFirst { it.pkg == pkg }
        if (ai < 0 || bi < 0) return
        val tmp = session[ai]
        session[ai] = session[bi]
        session[bi] = tmp
        val apps = running()
        val slotSnap = slotsFor(apps)
        val gen = generation.incrementAndGet()
        Thread {
            val out = layoutAll(apps, slotSnap, gen)
            if (!isStale(gen)) log(out)
        }.start()
    }

    /**
     * Force stops the app and removes it from the layout; the remaining apps are
     * re-tiled to fill the screen. It stays in the session list as "stopped".
     */
    fun stop(pkg: String) {
        val item = session.firstOrNull { it.pkg == pkg } ?: return
        if (pkg in stopped) return
        stopped.add(pkg)
        val apps = running()
        val slotSnap = slotsFor(apps)
        val gen = generation.incrementAndGet()
        log("Stopping ${item.label}...")
        Thread {
            ShizukuShell.exec("am force-stop $pkg")
            if (isStale(gen)) return@Thread
            Thread.sleep(500)
            val sb = StringBuilder("Stopped ${item.label}\n")
            sb.append(layoutAll(apps, slotSnap, gen))
            if (!isStale(gen)) log(sb.toString())
        }.start()
    }

    /**
     * Relaunches the app, puts it back in a tile and re-tiles everything. Also works
     * on an app that is still running but whose window got lost or minimized.
     */
    fun restore(pkg: String) {
        val ctx = appCtx ?: return
        val item = session.firstOrNull { it.pkg == pkg } ?: return
        val comp = ctx.packageManager.getLaunchIntentForPackage(pkg)?.component?.flattenToShortString()
        if (comp == null) { log("${item.label}: no launcher activity"); return }
        if (stopped.remove(pkg)) {
            // a restored app comes back as a small tile (or as the active one if nothing else runs)
            session.remove(item)
            session.add(item)
        }
        val apps = running()
        val slotSnap = slotsFor(apps)
        val gen = generation.incrementAndGet()
        log("Restoring ${item.label}...")
        Thread {
            val out = ShizukuShell.exec("am start -n $comp --windowingMode 5 2>&1")
            if (isStale(gen)) return@Thread
            Thread.sleep(1300)
            val sb = StringBuilder("${item.label}: ${out.lines().lastOrNull { it.isNotBlank() } ?: "started"}\n")
            sb.append(layoutAll(apps, slotSnap, gen))
            if (!isStale(gen)) log(sb.toString())
        }.start()
    }

    /** Removes the drawer, clears the session and ends MultiWin like a force stop. Tiled apps keep running. */
    fun quitSelf(ctx: Context) {
        val app = ctx.applicationContext
        generation.incrementAndGet()
        Thread { finishQuit(app) }.start()
    }

    /** Force stops every tiled app, then quits MultiWin. */
    fun closeAllAndQuit(ctx: Context) {
        val app = ctx.applicationContext
        val pkgs = session.map { it.pkg }.distinct()
        generation.incrementAndGet()
        Thread {
            if (pkgs.isNotEmpty()) {
                val out = ShizukuShell.exec(pkgs.joinToString("; ") { "am force-stop $it" })
                if (out.startsWith("ERR")) {
                    // do not quit if the apps could not be stopped
                    log("Close all failed: $out")
                    return@Thread
                }
            }
            finishQuit(app)
        }.start()
    }

    private fun finishQuit(app: Context) {
        session.clear()
        stopped.clear()
        try { app.stopService(Intent(app, ControlService::class.java)) } catch (e: Throwable) { }
        // force stop ourselves through Shizuku; fall back to killing the process
        ShizukuShell.exec("am force-stop ${app.packageName}")
        Thread.sleep(500)
        android.os.Process.killProcess(android.os.Process.myPid())
    }

    /** Blocking. Finds the app's task and resizes it to the rect. Returns a status line. */
    private fun place(pkg: String, r: Rect): String {
        val dump = ShizukuShell.exec("dumpsys activity activities | grep 'Task{'")
        val id = taskIdFor(dump, pkg) ?: return "task not found"
        val cmds = listOf(
            "am task resize $id ${r.left} ${r.top} ${r.right} ${r.bottom}",
            "am task resize $id ${r.left},${r.top},${r.right},${r.bottom}",
            "cmd activity task resize $id ${r.left} ${r.top} ${r.right} ${r.bottom}"
        )
        var last = ""
        for (c in cmds) {
            last = ShizukuShell.exec("$c 2>&1")
            val bad = listOf("rror", "sage", "xception", "nknown").any { last.contains(it) }
            if (!bad) return "task $id placed"
        }
        return "task $id resize failed: ${last.take(80)}"
    }

    private fun taskIdFor(dump: String, pkg: String): Int? {
        val re = Regex("""Task\{\w+ #(\d+)[^}]*?A=\d+:([\w.]+)""")
        return re.findAll(dump).firstOrNull { it.groupValues[2] == pkg }
            ?.groupValues?.get(1)?.toIntOrNull()
    }
}
