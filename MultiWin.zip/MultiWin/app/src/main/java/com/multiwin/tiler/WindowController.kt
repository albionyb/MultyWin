package com.multiwin.tiler

import android.content.Context
import android.graphics.Rect
import android.os.Handler
import android.os.Looper

data class AppItem(val label: String, val pkg: String)

/** Holds the current window session so both the app screen and the floating bubble can use it. */
object WindowController {
    private val handler = Handler(Looper.getMainLooper())

    // index 0 = active app. slots[i] is the screen area of position i.
    private var session = mutableListOf<AppItem>()
    private var slots: List<Rect> = emptyList()
    private var mode: LayoutMode = LayoutMode.BIG_STRIP

    var onLog: ((String) -> Unit)? = null

    /** App names in slot order; index 0 is the active app. */
    fun labels(): List<String> = session.map { it.label }

    private fun log(msg: String) { handler.post { onLog?.invoke(msg) } }

    fun launch(ctx: Context, picked: List<AppItem>, mode: LayoutMode, area: Rect) {
        val pm = ctx.applicationContext.packageManager
        this.mode = mode
        slots = Tiler.slotsIn(mode, picked.size, area)
        session = picked.toMutableList()
        val apps = session.toList()
        val slotSnap = slots
        Thread {
            val sb = StringBuilder()
            apps.forEachIndexed { i, app ->
                val comp = pm.getLaunchIntentForPackage(app.pkg)?.component?.flattenToShortString()
                if (comp == null) {
                    sb.appendLine("${app.label}: no launcher activity")
                    return@forEachIndexed
                }
                val out = ShizukuShell.exec("am start -n $comp --windowingMode 5 2>&1")
                sb.appendLine("${app.label}: ${out.lines().lastOrNull { it.isNotBlank() } ?: "started"}")
                Thread.sleep(1300)
                sb.appendLine("  " + place(app.pkg, slotSnap[i]))
            }
            sb.append(settle(apps, slotSnap))
            log(sb.toString())
        }.start()
    }

    /**
     * Apps often snap back to their own minimum size / aspect ratio after launch,
     * which makes one window overlap its neighbours. Re-apply bounds a couple of
     * times: small tiles first, the big active window last.
     */
    private fun settle(apps: List<AppItem>, slotSnap: List<Rect>): String {
        val sb = StringBuilder()
        val order = (1 until apps.size).toList() + 0
        repeat(3) { pass ->
            Thread.sleep(if (pass == 2) 1500L else 800L)
            for (idx in order) {
                if (idx >= slotSnap.size) continue
                val res = place(apps[idx].pkg, slotSnap[idx])
                if (pass == 2) sb.appendLine("${apps[idx].label} (settle): $res")
            }
        }
        return sb.toString()
    }

    /** Re-computes the layout for the current rotation and re-places every window. */
    fun retile(ctx: Context) {
        if (session.isEmpty()) return
        slots = Tiler.slotsIn(mode, session.size, ScreenArea.usable(ctx))
        val apps = session.toList()
        val slotSnap = slots
        Thread { log(settle(apps, slotSnap)) }.start()
    }

    /** Swaps the app in slot i with the active app (slot 0). */
    fun swap(i: Int) {
        if (i >= session.size) { log("No app in slot ${i + 1}"); return }
        val a = session[0]
        session[0] = session[i]
        session[i] = a
        val apps = session.toList()
        val slotSnap = slots
        Thread {
            val sb = StringBuilder()
            val order = (1 until apps.size).toList() + 0
            for (idx in order) {
                sb.appendLine("${apps[idx].label}: " + place(apps[idx].pkg, slotSnap[idx]))
            }
            sb.append(settle(apps, slotSnap))
            log(sb.toString())
        }.start()
    }

    /** Blocking. Finds the app's task and resizes it to the rect. Returns a status line. */
    private fun place(pkg: String, r: Rect): String {
        val dump = ShizukuShell.exec("dumpsys activity activities | grep 'Task{'")
        val id = taskIdFor(dump, pkg) ?: return "task not found"
        val cmds = listOf(
            "am task resize $id ${r.left} ${r.top} ${r.right} ${r.bottom}",
            "am task resize $id ${r.left},${r.top},${r.right},${r.bottom}",
            "cmd activity task resize $id ${r.left} ${r.top} ${r.right} ${r.bottom}"
        )
        var last = ""
        for (c in cmds) {
            last = ShizukuShell.exec("$c 2>&1")
            val bad = listOf("rror", "sage", "xception", "nknown").any { last.contains(it) }
            if (!bad) return "task $id placed"
        }
        return "task $id resize failed: ${last.take(80)}"
    }

    private fun taskIdFor(dump: String, pkg: String): Int? {
        val re = Regex("""Task\{\w+ #(\d+)[^}]*?A=\d+:([\w.]+)""")
        return re.findAll(dump).firstOrNull { it.groupValues[2] == pkg }
            ?.groupValues?.get(1)?.toIntOrNull()
    }
}
