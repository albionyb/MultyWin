package com.multiwin.tiler

import android.graphics.Rect

enum class LayoutMode(val label: String) {
    BIG_STRIP("1 big active + small strip"),
    GRID("Grid (2 columns)")
}

object Tiler {
    /** Returns one rect per app. Slot 0 is always the active (focused) slot. */
    fun slots(mode: LayoutMode, n: Int, w: Int, h: Int): List<Rect> = when (mode) {
        LayoutMode.BIG_STRIP -> {
            val bigH = (h * 0.62f).toInt()
            val small = n - 1
            val tileW = w / small
            buildList {
                add(Rect(0, 0, w, bigH))
                for (i in 0 until small) add(Rect(i * tileW, bigH, (i + 1) * tileW, h))
            }
        }
        LayoutMode.GRID -> {
            val cols = 2
            val rows = (n + cols - 1) / cols
            val cw = w / cols
            val ch = h / rows
            List(n) { i ->
                val c = i % cols
                val r = i / cols
                Rect(c * cw, r * ch, (c + 1) * cw, (r + 1) * ch)
            }
        }
    }
}
