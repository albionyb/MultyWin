package com.multiwin.tiler

import android.graphics.Rect

enum class LayoutMode(val label: String) {
    BIG_STRIP("1 big active + small strip"),
    GRID("Grid (2 columns)")
}

object Tiler {
    /** Share of the usable height given to the big active window. */
    const val BIG_RATIO = 0.60f

    /** Slots inside the usable screen area (below status bar, above nav bar). */
    fun slotsIn(mode: LayoutMode, n: Int, area: Rect): List<Rect> =
        slots(mode, n, area.width(), area.height()).map {
            Rect(it.left + area.left, it.top + area.top, it.right + area.left, it.bottom + area.top)
        }

    /**
     * Returns one rect per app. Slot 0 is always the active (focused) slot.
     * Tiles share exact edges and the last tile in each row/column reaches the
     * screen edge, so rounding never leaves an uncovered strip.
     */
    fun slots(mode: LayoutMode, n: Int, w: Int, h: Int): List<Rect> = when {
        n <= 0 -> emptyList()
        // a single app takes the whole area, so no blank strip is left behind
        n == 1 -> listOf(Rect(0, 0, w, h))
        else -> slotsFor(mode, n, w, h)
    }

    private fun slotsFor(mode: LayoutMode, n: Int, w: Int, h: Int): List<Rect> = when (mode) {
        LayoutMode.BIG_STRIP -> if (w > h) {
            // Landscape: big window on the left at full height, small tiles stacked on the right.
            val bigW = (w * BIG_RATIO).toInt()
            val small = (n - 1).coerceAtLeast(1)
            buildList {
                add(Rect(0, 0, bigW, h))
                for (i in 0 until small) {
                    add(Rect(bigW, h * i / small, w, h * (i + 1) / small))
                }
            }
        } else {
            val bigH = (h * BIG_RATIO).toInt()
            val small = (n - 1).coerceAtLeast(1)
            buildList {
                add(Rect(0, 0, w, bigH))
                for (i in 0 until small) {
                    val left = w * i / small
                    val right = w * (i + 1) / small
                    add(Rect(left, bigH, right, h))
                }
            }
        }
        LayoutMode.GRID -> {
            val cols = 2
            val rows = (n + cols - 1) / cols
            List(n) { i ->
                val c = i % cols
                val r = i / cols
                // last item in a row that is not full stretches to the full width
                val isLastInRow = c == cols - 1 || i == n - 1
                val left = w * c / cols
                val right = if (isLastInRow) w else w * (c + 1) / cols
                Rect(left, h * r / rows, right, h * (r + 1) / rows)
            }
        }
    }
}
