package com.multiwin.tiler

import rikka.shizuku.Shizuku

/** Runs shell commands as the Shizuku (adb shell) user. */
object ShizukuShell {
    private val newProcess by lazy {
        Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java
        ).apply { isAccessible = true }
    }

    fun exec(command: String): String = try {
        val p = newProcess.invoke(null, arrayOf("sh", "-c", command), null, null) as Process
        val out = p.inputStream.bufferedReader().readText()
        val err = p.errorStream.bufferedReader().readText()
        p.waitFor()
        (out + err).trim()
    } catch (e: Throwable) {
        "ERR: ${e.cause?.message ?: e.message}"
    }
}
