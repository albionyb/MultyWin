package com.multiwin.tiler

import rikka.shizuku.Shizuku

/** Runs shell commands as the Shizuku (adb shell) user. */
object ShizukuShell {
    private val newProcess by lazy {
        Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java
        ).apply { isAccessible = true }
    }

    fun exec(command: String): String = try {
        // stderr is merged into stdout so a full pipe can never block us
        val p = newProcess.invoke(null, arrayOf("sh", "-c", "($command) 2>&1"), null, null) as Process
        val out = p.inputStream.bufferedReader().readText()
        p.waitFor()
        out.trim()
    } catch (e: Throwable) {
        "ERR: ${e.cause?.message ?: e.message}"
    }
}
