package com.multiwin.tiler

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.TextView

/** Small shared look: colours, rounded shapes and flat "chip" buttons (no default Button chrome). */
object Ui {
    val BG = Color.parseColor("#0F1114")
    val SURFACE = Color.parseColor("#1A1E25")
    val SURFACE2 = Color.parseColor("#272C36")
    val ACCENT = Color.parseColor("#5B8CFF")
    val ACCENT_DIM = Color.argb(80, 91, 140, 255)
    val TEXT = Color.parseColor("#F2F4F7")
    val TEXT2 = Color.parseColor("#9AA3AF")
    val GOOD = Color.parseColor("#3DDC84")
    val WARN = Color.parseColor("#FFB84D")
    val BAD = Color.parseColor("#FF7B7B")

    fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density + 0.5f).toInt()

    fun rounded(color: Int, radiusPx: Int, strokeColor: Int = 0, strokePx: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radiusPx.toFloat()
            if (strokePx > 0) setStroke(strokePx, strokeColor)
        }

    fun oval(color: Int, strokeColor: Int = 0, strokePx: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(color)
            if (strokePx > 0) setStroke(strokePx, strokeColor)
        }

    fun ripple(content: Drawable): Drawable =
        RippleDrawable(ColorStateList.valueOf(Color.argb(60, 255, 255, 255)), content, null)

    /** Re-colours a chip (or any view) with a rounded, rippling fill. */
    fun setFill(view: View, color: Int, radiusPx: Int) {
        view.background = ripple(rounded(color, radiusPx))
    }

    /** Flat rounded button made from a TextView. */
    fun chip(
        ctx: Context,
        label: String,
        bg: Int,
        fg: Int,
        sizeSp: Float,
        radiusDp: Int,
        bold: Boolean = false,
        onClick: () -> Unit
    ): TextView = TextView(ctx).apply {
        text = label
        setTextColor(fg)
        textSize = sizeSp
        gravity = Gravity.CENTER
        maxLines = 1
        if (bold) typeface = Typeface.DEFAULT_BOLD
        background = ripple(rounded(bg, dp(ctx, radiusDp)))
        isClickable = true
        isFocusable = true
        setOnClickListener { onClick() }
    }
}
