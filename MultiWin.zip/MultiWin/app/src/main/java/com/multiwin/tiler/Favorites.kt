package com.multiwin.tiler

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** A saved combination: layout, size and app packages. The first package is the active app. */
data class Favorite(
    val name: String,
    val mode: LayoutMode,
    val pkgs: List<String>,
    val ratio: Float = Tiler.BIG_RATIO // share of the screen for the big active app
)

object Favorites {
    private fun prefs(ctx: Context) =
        ctx.applicationContext.getSharedPreferences("favorites", Context.MODE_PRIVATE)

    fun load(ctx: Context): MutableList<Favorite> {
        val out = mutableListOf<Favorite>()
        try {
            val arr = JSONArray(prefs(ctx).getString("list", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val pk = o.getJSONArray("pkgs")
                val mode = try {
                    LayoutMode.valueOf(o.getString("mode"))
                } catch (e: Exception) {
                    LayoutMode.BIG_STRIP
                }
                val ratio = o.optDouble("ratio", Tiler.BIG_RATIO.toDouble()).toFloat()
                    .coerceIn(Tiler.MIN_RATIO, Tiler.MAX_RATIO)
                out.add(Favorite(o.getString("name"), mode, List(pk.length()) { pk.getString(it) }, ratio))
            }
        } catch (e: Exception) {
            // corrupt data: start empty
        }
        return out
    }

    private fun write(ctx: Context, list: List<Favorite>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject()
                    .put("name", it.name)
                    .put("mode", it.mode.name)
                    .put("pkgs", JSONArray(it.pkgs))
                    .put("ratio", it.ratio.toDouble())
            )
        }
        prefs(ctx).edit().putString("list", arr.toString()).apply()
    }

    /** Saves a favorite; one with the same name is replaced. */
    fun add(ctx: Context, fav: Favorite) {
        val list = load(ctx)
        list.removeAll { it.name.equals(fav.name, ignoreCase = true) }
        list.add(fav)
        write(ctx, list)
    }

    fun remove(ctx: Context, name: String) {
        val list = load(ctx)
        list.removeAll { it.name == name }
        write(ctx, list)
    }
}
