package com.multiwin.tiler

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** A saved combination: layout plus app packages. The first package is the active app. */
data class Favorite(val name: String, val mode: LayoutMode, val pkgs: List<String>)

object Favorites {
    private fun prefs(ctx: Context) =
        ctx.applicationContext.getSharedPreferences("favorites", Context.MODE_PRIVATE)

    fun load(ctx: Context): MutableList<Favorite> {
        val out = mutableListOf<Favorite>()
        try {
            val arr = JSONArray(prefs(ctx).getString("list", "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val pk = o.getJSONArray("pkgs")
                val mode = try {
                    LayoutMode.valueOf(o.getString("mode"))
                } catch (e: Exception) {
                    LayoutMode.BIG_STRIP
                }
                out.add(Favorite(o.getString("name"), mode, List(pk.length()) { pk.getString(it) }))
            }
        } catch (e: Exception) {
            // corrupt data: start empty
        }
        return out
    }

    private fun write(ctx: Context, list: List<Favorite>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject()
                    .put("name", it.name)
                    .put("mode", it.mode.name)
                    .put("pkgs", JSONArray(it.pkgs))
            )
        }
        prefs(ctx).edit().putString("list", arr.toString()).apply()
    }

    /** Saves a favorite; one with the same name is replaced. */
    fun add(ctx: Context, fav: Favorite) {
        val list = load(ctx)
        list.removeAll { it.name.equals(fav.name, ignoreCase = true) }
        list.add(fav)
        write(ctx, list)
    }

    fun remove(ctx: Context, name: String) {
        val list = load(ctx)
        list.removeAll { it.name == name }
        write(ctx, list)
    }
}
