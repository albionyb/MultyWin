package com.multiwin.tiler

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

/**
 * Edge drawer: a thin handle on the right edge of the screen.
 * Swipe it left (or tap) to open the list. Per app: tap the name to swap it with the
 * active one, Restore relaunches it, Stop force stops it and re-tiles the rest.
 * At the bottom: Hide drawer, Quit MultiWin, Close all & quit.
 * Drag the handle up or down to move it. The list closes itself after a few seconds.
 */
class ControlService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var rootView: View? = null
    private lateinit var panel: LinearLayout
    private var expanded = false
    private val autoClose = Runnable { collapse() }

    override fun onBind(intent: Intent?): IBinder? = null

    // Never let the system bring the drawer back on its own after Quit / force stop.
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_NOT_STICKY

    private fun rounded(color: Int, radiusPx: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radiusPx.toFloat()
    }

    override fun onCreate() {
        super.onCreate()
        val manager = getSystemService(WINDOW_SERVICE) as WindowManager
        wm = manager
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            background = rounded(Color.argb(238, 28, 28, 30), dp(14))
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }

        val touchArea = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(26), dp(110))
        }
        val pill = View(this).apply {
            background = rounded(Color.argb(110, 255, 255, 255), dp(3))
            layoutParams = FrameLayout.LayoutParams(dp(5), dp(64), Gravity.CENTER)
        }
        touchArea.addView(pill)

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(panel)
            addView(touchArea)
        }

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 0
            y = (resources.displayMetrics.heightPixels * 0.4f).toInt()
        }

        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var downX = 0f
        var downY = 0f
        var startY = 0
        var dragging = false
        touchArea.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; startY = lp.y; dragging = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (dragging || (abs(dy) > slop && abs(dy) > abs(dx))) {
                        dragging = true
                        lp.y = startY + dy.toInt()
                        manager.updateViewLayout(row, lp)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!dragging) {
                        val dx = e.rawX - downX
                        when {
                            dx < -slop * 2 -> expand()
                            dx > slop * 2 -> collapse()
                            else -> if (expanded) collapse() else expand()
                        }
                    }
                }
            }
            true
        }

        manager.addView(row, lp)
        rootView = row
    }

    private fun expand() {
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        panel.removeAllViews()
        val entries = WindowController.entries()

        if (entries.none { !it.stopped }) {
            panel.addView(TextView(this).apply {
                text = "No apps"
                setTextColor(Color.LTGRAY)
                textSize = 13f
                setPadding(dp(4), dp(2), dp(4), dp(4))
            })
        }
        for (e in entries) {
            panel.addView(
                appRow(e),
                LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = dp(4) }
            )
        }

        panel.addView(footer("Hide drawer", Color.argb(170, 255, 255, 255)) { stopSelf() })
        panel.addView(footer("Quit MultiWin", Color.argb(230, 255, 150, 150)) {
            WindowController.quitSelf(this)
        })
        panel.addView(footer("Close all & quit", Color.argb(230, 255, 150, 150)) {
            WindowController.closeAllAndQuit(this)
        })
        panel.visibility = View.VISIBLE
        expanded = true
        handler.removeCallbacks(autoClose)
        handler.postDelayed(autoClose, 6000)
    }

    /** One drawer row: app name (tap to swap with the active app) + small Restore and Stop buttons. */
    private fun appRow(e: SessionEntry): View {
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val name = Button(this).apply {
            text = when {
                e.stopped -> "${e.item.label} (stopped)"
                e.active -> "\u25B6 ${e.item.label}"
                else -> e.item.label
            }
            textSize = 12f
            isAllCaps = false
            maxLines = 1
            ellipsize = if (e.stopped) TextUtils.TruncateAt.MIDDLE else TextUtils.TruncateAt.END
            setTextColor(Color.WHITE)
            setPadding(dp(6), 0, dp(6), 0)
            alpha = if (e.stopped) 0.5f else 1f
            background = rounded(
                if (e.active) Color.argb(120, 80, 160, 255) else Color.argb(60, 255, 255, 255),
                dp(10)
            )
            setOnClickListener {
                if (!e.stopped && !e.active) {
                    WindowController.swapWithActive(e.item.pkg)
                    collapse()
                }
            }
        }
        row.addView(name, LinearLayout.LayoutParams(dp(116), dp(40)))
        row.addView(
            smallButton("Restore", enabled = true) {
                WindowController.restore(e.item.pkg)
                expand()
            },
            LinearLayout.LayoutParams(dp(54), dp(40)).apply { leftMargin = dp(4) }
        )
        row.addView(
            smallButton("Stop", enabled = !e.stopped) {
                WindowController.stop(e.item.pkg)
                expand()
            },
            LinearLayout.LayoutParams(dp(44), dp(40)).apply { leftMargin = dp(4) }
        )
        return row
    }

    private fun smallButton(label: String, enabled: Boolean, onClick: () -> Unit): Button {
        val d = resources.displayMetrics.density
        return Button(this).apply {
            text = label
            textSize = 11f
            isAllCaps = false
            maxLines = 1
            minWidth = 0
            minHeight = 0
            minimumWidth = 0
            minimumHeight = 0
            setPadding(0, 0, 0, 0)
            setTextColor(Color.WHITE)
            isEnabled = enabled
            alpha = if (enabled) 1f else 0.35f
            background = rounded(Color.argb(60, 255, 255, 255), (10 * d).toInt())
            setOnClickListener { onClick() }
        }
    }

    private fun footer(label: String, color: Int, onClick: () -> Unit): TextView {
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        return TextView(this).apply {
            text = label
            setTextColor(color)
            textSize = 12f
            gravity = Gravity.CENTER
            setPadding(0, dp(9), 0, dp(5))
            setOnClickListener { onClick() }
        }
    }

    private fun collapse() {
        handler.removeCallbacks(autoClose)
        panel.visibility = View.GONE
        expanded = false
    }

    private val retileRunnable = Runnable { WindowController.retile(this) }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        // wait for the rotation to finish, then re-tile
        handler.removeCallbacks(retileRunnable)
        handler.postDelayed(retileRunnable, 1000)
    }

    override fun onDestroy() {
        handler.removeCallbacks(autoClose)
        handler.removeCallbacks(retileRunnable)
        rootView?.let { wm?.removeView(it) }
        rootView = null
        super.onDestroy()
    }
}
