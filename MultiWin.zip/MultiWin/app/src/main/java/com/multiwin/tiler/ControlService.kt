package com.multiwin.tiler

import android.app.Service
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Edge drawer: a thin handle on the right edge of the screen.
 * Swipe it left (or tap) to open the list. Per app: tap the name to swap it with the
 * active one, drag the handle (the three bars) to drop it on another app and swap places,
 * Restore relaunches it, Stop force stops it and re-tiles the rest.
 * The size slider sets how much of the screen the active app gets (Big + strip layout).
 * At the bottom: Hide drawer, Quit MultiWin, Close all & quit.
 * Drag the edge handle up or down to move the drawer. The list closes itself after a few seconds.
 */
class ControlService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var rootView: View? = null
    private lateinit var panel: LinearLayout
    private var expanded = false
    private val autoClose = Runnable { collapse() }

    // drag and place
    private val rowViews = mutableListOf<Pair<SessionEntry, View>>()
    private var dropTarget: Pair<SessionEntry, View>? = null

    private fun dp(v: Int) = Ui.dp(this, v)

    override fun onBind(intent: Intent?): IBinder? = null

    // Never let the system bring the drawer back on its own after Quit / force stop.
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_NOT_STICKY

    override fun onCreate() {
        super.onCreate()
        val manager = getSystemService(WINDOW_SERVICE) as WindowManager
        wm = manager

        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            background = Ui.rounded(Color.argb(246, 22, 25, 31), dp(18), Color.argb(40, 255, 255, 255), 1)
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }

        val touchArea = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(26), dp(110))
        }
        val pill = View(this).apply {
            background = Ui.rounded(Color.argb(150, 255, 255, 255), dp(3))
            layoutParams = FrameLayout.LayoutParams(dp(5), dp(64), Gravity.CENTER)
        }
        touchArea.addView(pill)

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(panel)
            addView(touchArea)
        }

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 0
            y = (resources.displayMetrics.heightPixels * 0.4f).toInt()
        }

        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var downX = 0f
        var downY = 0f
        var startY = 0
        var dragging = false
        touchArea.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; startY = lp.y; dragging = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (dragging || (abs(dy) > slop && abs(dy) > abs(dx))) {
                        dragging = true
                        lp.y = startY + dy.toInt()
                        manager.updateViewLayout(row, lp)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!dragging) {
                        val dx = e.rawX - downX
                        when {
                            dx < -slop * 2 -> expand()
                            dx > slop * 2 -> collapse()
                            else -> if (expanded) collapse() else expand()
                        }
                    }
                }
            }
            true
        }

        manager.addView(row, lp)
        rootView = row
    }

    private fun expand() {
        panel.removeAllViews()
        rowViews.clear()
        dropTarget = null
        val entries = WindowController.entries()
        val runningCount = entries.count { !it.stopped }

        // header
        panel.addView(TextView(this).apply {
            text = "MultiWin"
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Ui.TEXT)
        })
        panel.addView(TextView(this).apply {
            text = if (runningCount >= 2) "Drag \u2261 onto another app to swap places" else "Tiled apps"
            textSize = 10.5f
            setTextColor(Ui.TEXT2)
        })

        if (runningCount == 0) {
            panel.addView(TextView(this).apply {
                text = "No apps"
                setTextColor(Ui.TEXT2)
                textSize = 13f
                setPadding(dp(2), dp(8), dp(2), dp(4))
            })
        }

        var slot = 0
        for (e in entries) {
            if (!e.stopped) slot++
            val row = appRow(e, slot, runningCount >= 2)
            rowViews.add(e to row)
            panel.addView(
                row,
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(46))
                    .apply { topMargin = dp(6) }
            )
        }

        if (runningCount >= 2 && WindowController.currentMode() == LayoutMode.BIG_STRIP) {
            addSizeControl()
        }

        panel.addView(
            Ui.chip(this, "Hide drawer", Color.argb(40, 255, 255, 255), Ui.TEXT, 12f, 10) { stopSelf() },
            footerLp(12)
        )
        panel.addView(
            Ui.chip(this, "Quit MultiWin", Color.argb(55, 255, 123, 123), Ui.BAD, 12f, 10) {
                WindowController.quitSelf(this)
            },
            footerLp(5)
        )
        panel.addView(
            Ui.chip(this, "Close all & quit", Color.argb(100, 255, 123, 123), Ui.TEXT, 12f, 10, bold = true) {
                WindowController.closeAllAndQuit(this)
            },
            footerLp(5)
        )

        panel.visibility = View.VISIBLE
        expanded = true
        handler.removeCallbacks(autoClose)
        handler.postDelayed(autoClose, 6000)
    }

    /** Custom size: how much of the screen the big active app gets. Applied when you let go. */
    private fun addSizeControl() {
        val minPct = (Tiler.MIN_RATIO * 100).roundToInt()
        val maxPct = (Tiler.MAX_RATIO * 100).roundToInt()
        val pct = (WindowController.currentRatio() * 100).roundToInt().coerceIn(minPct, maxPct)

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.rounded(Color.argb(30, 255, 255, 255), dp(12))
            setPadding(dp(8), dp(6), dp(8), dp(4))
        }
        val valueView = TextView(this).apply {
            text = "$pct%"
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Ui.ACCENT)
        }
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        head.addView(
            TextView(this).apply {
                text = "Active app size"
                textSize = 12f
                setTextColor(Ui.TEXT)
            },
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        )
        head.addView(valueView)
        val reset = Ui.chip(this, "Reset", Color.argb(45, 255, 255, 255), Ui.TEXT, 11f, 9) {
            WindowController.resetRatio()
            expand()
        }
        reset.setPadding(dp(9), 0, dp(9), 0)
        head.addView(
            reset,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(26)).apply { leftMargin = dp(8) }
        )
        box.addView(head)

        val seek = SeekBar(this).apply {
            max = maxPct - minPct
            progress = pct - minPct
            progressTintList = ColorStateList.valueOf(Ui.ACCENT)
            thumbTintList = ColorStateList.valueOf(Color.WHITE)
            progressBackgroundTintList = ColorStateList.valueOf(Color.argb(70, 255, 255, 255))
            setPadding(dp(12), dp(6), dp(12), dp(6))
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    valueView.text = "${p + minPct}%"
                }

                override fun onStartTrackingTouch(sb: SeekBar?) {
                    handler.removeCallbacks(autoClose)
                }

                override fun onStopTrackingTouch(sb: SeekBar?) {
                    val p = sb?.progress ?: return
                    WindowController.setRatio((p + minPct) / 100f)
                    handler.removeCallbacks(autoClose)
                    handler.postDelayed(autoClose, 6000)
                }
            })
        }
        box.addView(seek, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(32)))

        panel.addView(
            box,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .apply { topMargin = dp(10) }
        )
    }

    private fun footerLp(topDp: Int) =
        LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(36)).apply { topMargin = dp(topDp) }

    private fun rowBackground(e: SessionEntry, highlighted: Boolean): GradientDrawable = when {
        highlighted -> Ui.rounded(Ui.ACCENT_DIM, dp(12), Ui.ACCENT, dp(2))
        e.active -> Ui.rounded(Ui.ACCENT_DIM, dp(12))
        e.stopped -> Ui.rounded(Color.argb(18, 255, 255, 255), dp(12))
        else -> Ui.rounded(Color.argb(36, 255, 255, 255), dp(12))
    }

    /**
     * One drawer row: drag handle, icon, name (tap to swap with the active app),
     * and small Restore and Stop buttons.
     */
    private fun appRow(e: SessionEntry, slot: Int, draggable: Boolean): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = rowBackground(e, false)
            setPadding(dp(2), 0, dp(6), 0)
        }

        val canDrag = draggable && !e.stopped
        val handle = TextView(this).apply {
            text = if (canDrag) "\u2261" else ""
            textSize = 20f
            setTextColor(Ui.TEXT2)
            gravity = Gravity.CENTER
        }
        row.addView(handle, LinearLayout.LayoutParams(dp(28), LinearLayout.LayoutParams.MATCH_PARENT))
        if (canDrag) attachDrag(handle, row, e)

        val icon = ImageView(this).apply {
            try {
                setImageDrawable(this@ControlService.packageManager.getApplicationIcon(e.item.pkg))
            } catch (ex: Exception) {
            }
            alpha = if (e.stopped) 0.4f else 1f
        }
        row.addView(icon, LinearLayout.LayoutParams(dp(26), dp(26)).apply { rightMargin = dp(8) })

        val nameCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setOnClickListener {
                if (!e.stopped && !e.active) {
                    WindowController.swapWithActive(e.item.pkg)
                    collapse()
                }
            }
        }
        nameCol.addView(TextView(this).apply {
            text = e.item.label
            textSize = 13f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setTextColor(if (e.stopped) Ui.TEXT2 else Ui.TEXT)
            if (e.active) typeface = Typeface.DEFAULT_BOLD
        })
        nameCol.addView(TextView(this).apply {
            text = when {
                e.stopped -> "stopped"
                e.active -> "Active"
                else -> "Slot $slot"
            }
            textSize = 10f
            setTextColor(
                when {
                    e.stopped -> Ui.BAD
                    e.active -> Ui.ACCENT
                    else -> Ui.TEXT2
                }
            )
        })
        row.addView(nameCol, LinearLayout.LayoutParams(dp(92), LinearLayout.LayoutParams.WRAP_CONTENT))

        val restore = Ui.chip(this, "Restore", Color.argb(45, 255, 255, 255), Ui.TEXT, 11f, 9) {
            WindowController.restore(e.item.pkg)
            expand()
        }
        restore.setPadding(dp(9), 0, dp(9), 0)
        row.addView(
            restore,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(30)).apply { leftMargin = dp(2) }
        )

        val stop = Ui.chip(this, "Stop", Color.argb(60, 255, 123, 123), Ui.BAD, 11f, 9) {
            WindowController.stop(e.item.pkg)
            expand()
        }
        stop.setPadding(dp(9), 0, dp(9), 0)
        if (e.stopped) {
            stop.isEnabled = false
            stop.alpha = 0.35f
        }
        row.addView(
            stop,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(30)).apply { leftMargin = dp(4) }
        )
        return row
    }

    // ---------- drag and place ----------

    /** Drag the handle of a row onto another running row and release to swap their tiles. */
    private fun attachDrag(handle: View, row: View, e: SessionEntry) {
        var startY = 0f
        handle.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startY = ev.rawY
                    handler.removeCallbacks(autoClose)
                    row.translationZ = dp(12).toFloat()
                    row.scaleX = 1.03f
                    row.scaleY = 1.03f
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    row.translationY = ev.rawY - startY
                    updateDropTarget(row)
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    finishDrag(row, e, ev.actionMasked == MotionEvent.ACTION_UP)
                    true
                }
                else -> false
            }
        }
    }

    private fun updateDropTarget(dragged: View) {
        val cy = dragged.top + dragged.translationY + dragged.height / 2f
        val hit = rowViews.firstOrNull { (en, v) ->
            v !== dragged && !en.stopped && cy >= v.top && cy <= v.bottom
        }
        if (hit?.second === dropTarget?.second) return
        dropTarget?.let { (en, v) -> v.background = rowBackground(en, false) }
        hit?.let { (en, v) -> v.background = rowBackground(en, true) }
        dropTarget = hit
    }

    private fun finishDrag(row: View, e: SessionEntry, commit: Boolean) {
        val t = dropTarget
        dropTarget = null
        if (commit && t != null) {
            WindowController.swapApps(e.item.pkg, t.first.item.pkg)
            // rebuild after the touch has finished
            handler.post { expand() }
        } else {
            row.translationY = 0f
            row.translationZ = 0f
            row.scaleX = 1f
            row.scaleY = 1f
            t?.let { (en, v) -> v.background = rowBackground(en, false) }
            handler.removeCallbacks(autoClose)
            handler.postDelayed(autoClose, 6000)
        }
    }

    private fun collapse() {
        handler.removeCallbacks(autoClose)
        panel.visibility = View.GONE
        expanded = false
    }

    private val retileRunnable = Runnable { WindowController.retile(this) }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        // wait for the rotation to finish, then re-tile
        handler.removeCallbacks(retileRunnable)
        handler.postDelayed(retileRunnable, 1000)
    }

    override fun onDestroy() {
        handler.removeCallbacks(autoClose)
        handler.removeCallbacks(retileRunnable)
        rootView?.let { wm?.removeView(it) }
        rootView = null
        super.onDestroy()
    }
}
