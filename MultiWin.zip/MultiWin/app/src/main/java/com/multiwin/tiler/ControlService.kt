package com.multiwin.tiler

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** Small always-on-top bar with swap buttons. Drag the handle to move it. */
class ControlService : Service() {

    private var bar: View? = null
    private var wm: WindowManager? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val manager = getSystemService(WINDOW_SERVICE) as WindowManager
        wm = manager
        val d = resources.displayMetrics.density

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.argb(210, 20, 20, 20))
            setPadding((4 * d).toInt(), (2 * d).toInt(), (4 * d).toInt(), (2 * d).toInt())
        }
        val handle = TextView(this).apply {
            text = "\u2261"
            textSize = 24f
            setTextColor(Color.WHITE)
            setPadding((10 * d).toInt(), 0, (10 * d).toInt(), 0)
            gravity = Gravity.CENTER
        }
        row.addView(handle)
        for (i in 1..3) row.addView(smallButton("\u21C4${i + 1}") { WindowController.swap(i) })
        row.addView(smallButton("\u2715") { stopSelf() })

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (8 * d).toInt()
            y = (300 * d).toInt()
        }

        var startX = 0
        var startY = 0
        var downX = 0f
        var downY = 0f
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y
                    downX = e.rawX; downY = e.rawY
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = startX + (e.rawX - downX).toInt()
                    lp.y = startY + (e.rawY - downY).toInt()
                    manager.updateViewLayout(row, lp)
                }
            }
            true
        }

        manager.addView(row, lp)
        bar = row
    }

    private fun smallButton(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        textSize = 13f
        isAllCaps = false
        minWidth = 0
        minimumWidth = 0
        setOnClickListener { onClick() }
    }

    override fun onDestroy() {
        bar?.let { wm?.removeView(it) }
        bar = null
        super.onDestroy()
    }
}
