package com.multiwin.tiler

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs

/**
 * Edge drawer: a thin handle on the right edge of the screen.
 * Swipe it left (or tap) to open the list, tap an app to make it the active one.
 * Drag it up or down to move it. It closes itself after a few seconds.
 */
class ControlService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var rootView: View? = null
    private lateinit var panel: LinearLayout
    private var expanded = false
    private val autoClose = Runnable { collapse() }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun rounded(color: Int, radiusPx: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radiusPx.toFloat()
    }

    override fun onCreate() {
        super.onCreate()
        val manager = getSystemService(WINDOW_SERVICE) as WindowManager
        wm = manager
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            background = rounded(Color.argb(238, 28, 28, 30), dp(14))
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }

        val touchArea = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(26), dp(110))
        }
        val pill = View(this).apply {
            background = rounded(Color.argb(110, 255, 255, 255), dp(3))
            layoutParams = FrameLayout.LayoutParams(dp(5), dp(64), Gravity.CENTER)
        }
        touchArea.addView(pill)

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(panel)
            addView(touchArea)
        }

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 0
            y = (resources.displayMetrics.heightPixels * 0.4f).toInt()
        }

        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var downX = 0f
        var downY = 0f
        var startY = 0
        var dragging = false
        touchArea.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; startY = lp.y; dragging = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (dragging || (abs(dy) > slop && abs(dy) > abs(dx))) {
                        dragging = true
                        lp.y = startY + dy.toInt()
                        manager.updateViewLayout(row, lp)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!dragging) {
                        val dx = e.rawX - downX
                        when {
                            dx < -slop * 2 -> expand()
                            dx > slop * 2 -> collapse()
                            else -> if (expanded) collapse() else expand()
                        }
                    }
                }
            }
            true
        }

        manager.addView(row, lp)
        rootView = row
    }

    private fun expand() {
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        panel.removeAllViews()
        val names = WindowController.labels()
        if (names.size < 2) {
            panel.addView(TextView(this).apply {
                text = "Launch apps first"
                setTextColor(Color.LTGRAY)
                textSize = 13f
            })
        } else {
            panel.addView(TextView(this).apply {
                text = "Active: ${names[0]}"
                setTextColor(Color.argb(180, 255, 255, 255))
                textSize = 11f
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                setPadding(dp(4), 0, dp(4), dp(4))
            })
            for (i in 1 until names.size) {
                panel.addView(
                    Button(this).apply {
                        text = names[i]
                        textSize = 13f
                        isAllCaps = false
                        maxLines = 1
                        ellipsize = TextUtils.TruncateAt.END
                        setTextColor(Color.WHITE)
                        background = rounded(Color.argb(60, 255, 255, 255), dp(10))
                        setOnClickListener {
                            WindowController.swap(i)
                            collapse()
                        }
                    },
                    LinearLayout.LayoutParams(dp(150), dp(44)).apply { topMargin = dp(4) }
                )
            }
        }
        panel.addView(
            TextView(this).apply {
                text = "Hide drawer"
                setTextColor(Color.argb(150, 255, 255, 255))
                textSize = 11f
                gravity = Gravity.CENTER
                setPadding(0, dp(8), 0, dp(2))
                setOnClickListener { stopSelf() }
            },
            LinearLayout.LayoutParams(dp(150), LinearLayout.LayoutParams.WRAP_CONTENT)
        )
        panel.visibility = View.VISIBLE
        expanded = true
        handler.removeCallbacks(autoClose)
        handler.postDelayed(autoClose, 4000)
    }

    private fun collapse() {
        handler.removeCallbacks(autoClose)
        panel.visibility = View.GONE
        expanded = false
    }

    private val retileRunnable = Runnable { WindowController.retile(this) }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        // wait for the rotation to finish, then re-tile
        handler.removeCallbacks(retileRunnable)
        handler.postDelayed(retileRunnable, 1000)
    }

    override fun onDestroy() {
        handler.removeCallbacks(autoClose)
        handler.removeCallbacks(retileRunnable)
        rootView?.let { wm?.removeView(it) }
        rootView = null
        super.onDestroy()
    }
}
