package com.multiwin.tiler

import kotlin.system.exitProcess

/** Runs inside the Shizuku shell process, so commands here have ADB-level rights. */
class ShellService : IUserService.Stub() {

    override fun destroy() {
        exitProcess(0)
    }

    override fun exec(command: String): String = try {
        val p = ProcessBuilder("sh", "-c", command).redirectErrorStream(true).start()
        val out = p.inputStream.bufferedReader().readText()
        p.waitFor()
        out
    } catch (e: Exception) {
        "ERR: ${e.message}"
    }
}
