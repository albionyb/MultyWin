package com.multiwin.tiler

import android.app.Activity
import android.app.ActivityOptions
import android.content.ComponentName
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.graphics.Rect
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    private data class AppItem(val label: String, val pkg: String)

    private val handler = Handler(Looper.getMainLooper())
    private var shell: IUserService? = null

    private val apps = mutableListOf<AppItem>()
    private lateinit var status: TextView
    private lateinit var list: ListView
    private lateinit var modeSpinner: Spinner

    // Current session: index 0 = active app. slots[i] is the screen area of position i.
    private var session = mutableListOf<AppItem>()
    private var slots: List<Rect> = emptyList()

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            shell = IUserService.Stub.asInterface(binder)
            refresh()
        }

        override fun onServiceDisconnected(name: ComponentName) {
            shell = null
            refresh()
        }
    }

    private val permListener = Shizuku.OnRequestPermissionResultListener { _, result ->
        if (result == PackageManager.PERMISSION_GRANTED) bindShell()
        refresh()
    }
    private val binderListener = Shizuku.OnBinderReceivedListener {
        if (hasPermission()) bindShell()
        refresh()
    }
    private val deadListener = Shizuku.OnBinderDeadListener {
        shell = null
        refresh()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        val pad = (16 * d).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }

        status = TextView(this).apply { textSize = 14f }
        root.addView(status)

        root.addView(button("Grant Shizuku permission") { requestShizuku() })
        root.addView(button("Enable freeform windows (reboot after)") { enableFreeform() })

        modeSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                LayoutMode.values().map { it.label }
            )
        }
        root.addView(modeSpinner)

        list = ListView(this).apply { choiceMode = ListView.CHOICE_MODE_MULTIPLE }
        list.onItemClickListener = AdapterView.OnItemClickListener { _, _, _, _ ->
            if (list.checkedItemCount > 4) {
                toast("Max 4 apps")
                for (i in 0 until list.count) if (list.isItemChecked(i)) { list.setItemChecked(i, false); break }
            }
        }
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))

        root.addView(button("Launch selected (first = active)") { launchSelected() })

        val swapRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (i in 1..3) {
            swapRow.addView(
                button("Swap ${i + 1}") { swap(i) },
                LinearLayout.LayoutParams(0, -2, 1f)
            )
        }
        root.addView(swapRow)
        setContentView(root)

        loadApps()

        Shizuku.addRequestPermissionResultListener(permListener)
        Shizuku.addBinderReceivedListenerSticky(binderListener)
        Shizuku.addBinderDeadListener(deadListener)
        refresh()
    }

    override fun onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permListener)
        Shizuku.removeBinderReceivedListener(binderListener)
        Shizuku.removeBinderDeadListener(deadListener)
        super.onDestroy()
    }

    // ---------- Shizuku ----------

    private fun hasPermission() = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) { false }

    private fun requestShizuku() {
        if (!Shizuku.pingBinder()) {
            toast("Start Shizuku first (wireless debugging)")
            return
        }
        if (hasPermission()) bindShell() else Shizuku.requestPermission(1001)
    }

    private fun bindShell() {
        val args = Shizuku.UserServiceArgs(ComponentName(packageName, ShellService::class.java.name))
            .daemon(false)
            .processNameSuffix("shell")
            .version(1)
        Shizuku.bindUserService(args, conn)
    }

    private fun sh(cmd: String, done: (String) -> Unit = {}) {
        val s = shell ?: run { toast("Shizuku not connected"); return }
        Thread {
            val out = try { s.exec(cmd) } catch (e: Exception) { "ERR: ${e.message}" }
            handler.post { done(out) }
        }.start()
    }

    private fun refresh() {
        status.text = when {
            !Shizuku.pingBinder() -> "Shizuku: not running"
            !hasPermission() -> "Shizuku: running, permission needed"
            shell == null -> "Shizuku: connecting..."
            else -> "Shizuku: connected"
        }
    }

    private fun enableFreeform() {
        sh(
            "settings put global enable_freeform_support 1; " +
                "settings put global force_resizable_activities 1; " +
                "settings put global freeform_window_management 1"
        ) { toast("Done. Reboot the phone once.") }
    }

    // ---------- App list ----------

    private fun loadApps() {
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val found = packageManager.queryIntentActivities(q, 0)
            .map { AppItem(it.loadLabel(packageManager).toString(), it.activityInfo.packageName) }
            .filter { it.pkg != packageName }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
        apps.clear()
        apps.addAll(found)
        list.adapter = ArrayAdapter(
            this, android.R.layout.simple_list_item_multiple_choice, apps.map { it.label }
        )
    }

    // ---------- Launch and swap ----------

    private fun launchSelected() {
        val picked = (0 until apps.size).filter { list.isItemChecked(it) }.map { apps[it] }
        if (picked.size < 2) { toast("Pick 2 to 4 apps"); return }

        val m = resources.displayMetrics
        val mode = LayoutMode.values()[modeSpinner.selectedItemPosition]
        slots = Tiler.slots(mode, picked.size, m.widthPixels, m.heightPixels)
        session = picked.toMutableList()

        session.forEachIndexed { i, app ->
            handler.postDelayed({ startInSlot(app, slots[i]) }, i * 700L)
        }
        // Second pass with Shizuku in case the system ignored the launch bounds.
        if (shell != null) {
            handler.postDelayed({ applyAll() }, session.size * 700L + 1200L)
        }
    }

    private fun startInSlot(app: AppItem, rect: Rect) {
        val intent = packageManager.getLaunchIntentForPackage(app.pkg) ?: return
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val opts = ActivityOptions.makeBasic().setLaunchBounds(rect)
        try {
            startActivity(intent, opts.toBundle())
        } catch (e: Exception) {
            toast("Could not start ${app.label}")
        }
    }

    private fun swap(i: Int) {
        if (i >= session.size) { toast("No app in slot ${i + 1}"); return }
        val a = session[0]
        session[0] = session[i]
        session[i] = a
        applyAll()
    }

    /** Moves each running task into its slot with `am task resize`. */
    private fun applyAll() {
        sh("dumpsys activity activities") { dump ->
            session.forEachIndexed { i, app ->
                val id = taskIdFor(dump, app.pkg) ?: return@forEachIndexed
                val r = slots[i]
                val spaced = "am task resize $id ${r.left} ${r.top} ${r.right} ${r.bottom}"
                val comma = "am task resize $id ${r.left},${r.top},${r.right},${r.bottom}"
                // Argument format differs between Android versions, so try both.
                sh("$spaced 2>&1 || $comma 2>&1")
            }
        }
    }

    private fun taskIdFor(dump: String, pkg: String): Int? {
        val re = Regex("""Task\{\w+ #(\d+)[^}]*?A=\d+:([\w.]+)""")
        return re.findAll(dump).firstOrNull { it.groupValues[2] == pkg }
            ?.groupValues?.get(1)?.toIntOrNull()
    }

    // ---------- Helpers ----------

    private fun button(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
