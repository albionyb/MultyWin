package com.multiwin.tiler

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())

    private val allApps = mutableListOf<AppItem>()
    private val apps = mutableListOf<AppItem>() // currently shown (filtered)
    private val pickOrder = mutableListOf<String>() // tap order; first tapped = active app
    private val iconCache = mutableMapOf<String, Drawable?>()
    private lateinit var status: TextView
    private lateinit var statusDot: View
    private lateinit var logView: TextView
    private lateinit var list: ListView
    private lateinit var adapter: AppAdapter
    private lateinit var pickView: TextView
    private lateinit var searchBox: EditText
    private lateinit var grantBtn: TextView
    private lateinit var launchBtn: TextView
    private val modeChips = mutableMapOf<LayoutMode, TextView>()
    private var selectedMode = LayoutMode.BIG_STRIP

    private var shellInfo: String? = null
    private var checking = false

    private val permListener = Shizuku.OnRequestPermissionResultListener { _, _ ->
        shellInfo = null
        refresh()
    }
    private val binderListener = Shizuku.OnBinderReceivedListener {
        shellInfo = null
        refresh()
    }
    private val deadListener = Shizuku.OnBinderDeadListener {
        shellInfo = null
        refresh()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.setBackgroundColor(Ui.BG)
        window.statusBarColor = Ui.BG
        window.navigationBarColor = Ui.BG

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.BG)
            setPadding(dp(16), dp(34), dp(16), dp(12))
        }

        // header: title + connection status pill
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titles.addView(TextView(this).apply {
            text = "MultiWin"
            textSize = 26f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Ui.TEXT)
        })
        titles.addView(TextView(this).apply {
            text = "Tile 2 to 4 apps on one screen"
            textSize = 12f
            setTextColor(Ui.TEXT2)
        })
        header.addView(titles, LinearLayout.LayoutParams(0, -2, 1f))
        statusDot = View(this).apply { background = Ui.oval(Ui.TEXT2) }
        status = TextView(this).apply { textSize = 12f; setTextColor(Ui.TEXT) }
        val pill = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = Ui.rounded(Ui.SURFACE, dp(20))
            setPadding(dp(11), dp(7), dp(13), dp(7))
            addView(statusDot, LinearLayout.LayoutParams(dp(8), dp(8)).apply { rightMargin = dp(7) })
            addView(status)
        }
        header.addView(pill)
        root.addView(header)

        logView = TextView(this).apply {
            textSize = 11f
            maxLines = 6
            setTextColor(Ui.TEXT2)
            visibility = View.GONE
            setPadding(0, dp(8), 0, 0)
        }
        root.addView(logView)
        WindowController.onLog = { setLog(it) }

        // setup card
        val setup = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = Ui.rounded(Ui.SURFACE, dp(16))
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        grantBtn = Ui.chip(this, "Grant Shizuku permission", Ui.SURFACE2, Ui.TEXT, 12f, 12) { requestShizuku() }
            .apply { maxLines = 2; setPadding(dp(8), 0, dp(8), 0) }
        val freeformBtn = Ui.chip(this, "Enable freeform windows (reboot after)", Ui.SURFACE2, Ui.TEXT, 12f, 12) {
            enableFreeform()
        }.apply { maxLines = 2; setPadding(dp(8), 0, dp(8), 0) }
        setup.addView(grantBtn, LinearLayout.LayoutParams(0, dp(48), 1f))
        setup.addView(freeformBtn, LinearLayout.LayoutParams(0, dp(48), 1f).apply { leftMargin = dp(8) })
        root.addView(setup, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })

        // layout segmented control
        val seg = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = Ui.rounded(Ui.SURFACE, dp(13))
            setPadding(dp(3), dp(3), dp(3), dp(3))
        }
        for (m in LayoutMode.values()) {
            val c = Ui.chip(this, modeShort(m), Color.TRANSPARENT, Ui.TEXT2, 13f, 10) { setMode(m) }
            modeChips[m] = c
            seg.addView(c, LinearLayout.LayoutParams(0, dp(36), 1f).apply { if (m.ordinal > 0) leftMargin = dp(3) })
        }
        root.addView(seg, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        setMode(selectedMode)

        searchBox = EditText(this).apply {
            hint = "Search apps"
            setSingleLine()
            textSize = 14f
            setTextColor(Ui.TEXT)
            setHintTextColor(Ui.TEXT2)
            background = Ui.rounded(Ui.SURFACE, dp(13))
            setPadding(dp(14), dp(10), dp(14), dp(10))
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) { applyFilter(s?.toString().orEmpty()) }
            })
        }
        root.addView(searchBox, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        pickView = TextView(this).apply {
            textSize = 12f
            setTextColor(Ui.TEXT2)
            setPadding(dp(2), dp(8), dp(2), dp(6))
        }
        root.addView(pickView)

        adapter = AppAdapter()
        list = ListView(this).apply {
            divider = null
            dividerHeight = dp(4)
            selector = ColorDrawable(Color.TRANSPARENT)
            overScrollMode = View.OVER_SCROLL_NEVER
            this.adapter = this@MainActivity.adapter
        }
        list.onItemClickListener = AdapterView.OnItemClickListener { _, _, pos, _ ->
            val pkg = apps[pos].pkg
            if (pkg in pickOrder) {
                pickOrder.remove(pkg)
            } else if (pickOrder.size >= 4) {
                toast("Max 4 apps")
            } else {
                pickOrder.add(pkg)
            }
            adapter.notifyDataSetChanged()
            updatePickView()
        }
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))

        // bottom actions
        launchBtn = Ui.chip(this, "Launch", Ui.ACCENT, Color.WHITE, 16f, 16, bold = true) { launchSelected() }
        root.addView(launchBtn, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(8) })

        val favRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        favRow.addView(
            Ui.chip(this, "\u2605 Save", Ui.SURFACE2, Ui.TEXT, 13f, 14) { saveFavorite() },
            LinearLayout.LayoutParams(0, dp(44), 1f)
        )
        favRow.addView(
            Ui.chip(this, "\u2605 Favorites", Ui.SURFACE2, Ui.TEXT, 13f, 14) { showFavorites() },
            LinearLayout.LayoutParams(0, dp(44), 1f).apply { leftMargin = dp(8) }
        )
        root.addView(favRow, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        val quitRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        quitRow.addView(
            Ui.chip(this, "Quit MultiWin", Color.TRANSPARENT, Ui.TEXT2, 12f, 12) { quitMultiWin() },
            LinearLayout.LayoutParams(0, dp(38), 1f)
        )
        quitRow.addView(
            Ui.chip(this, "Close all & quit", Color.TRANSPARENT, Ui.BAD, 12f, 12) { confirmCloseAllAndQuit() },
            LinearLayout.LayoutParams(0, dp(38), 1f)
        )
        root.addView(quitRow, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
        setContentView(root)

        loadApps()

        Shizuku.addRequestPermissionResultListener(permListener)
        Shizuku.addBinderReceivedListenerSticky(binderListener)
        Shizuku.addBinderDeadListener(deadListener)
        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onDestroy() {
        WindowController.onLog = null
        Shizuku.removeRequestPermissionResultListener(permListener)
        Shizuku.removeBinderReceivedListener(binderListener)
        Shizuku.removeBinderDeadListener(deadListener)
        super.onDestroy()
    }

    // ---------- Shizuku ----------

    private fun hasPermission() = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) { false }

    private fun requestShizuku() {
        if (!Shizuku.pingBinder()) {
            toast("Start Shizuku first")
            return
        }
        if (hasPermission()) { shellInfo = null; refresh() } else Shizuku.requestPermission(1001)
    }

    private fun sh(cmd: String, done: (String) -> Unit = {}) {
        if (!hasPermission()) { toast("Shizuku not connected"); return }
        Thread {
            val out = ShizukuShell.exec(cmd)
            handler.post { done(out) }
        }.start()
    }

    private fun setStatus(text: String, color: Int) {
        status.text = text
        statusDot.background = Ui.oval(color)
    }

    private fun refresh() {
        val ping = try { Shizuku.pingBinder() } catch (e: Throwable) { false }
        grantBtn.visibility = if (hasPermission()) View.GONE else View.VISIBLE
        when {
            !ping -> setStatus("Shizuku not running", Ui.BAD)
            !hasPermission() -> setStatus("Permission needed", Ui.WARN)
            shellInfo == null -> {
                setStatus("Testing...", Ui.WARN)
                if (!checking) {
                    checking = true
                    sh("id") { out ->
                        checking = false
                        shellInfo = out.ifBlank { "no output" }
                        refresh()
                    }
                }
            }
            else -> setStatus("Shizuku connected", Ui.GOOD)
        }
    }

    private fun enableFreeform() {
        sh(
            "settings put global enable_freeform_support 1; " +
                "settings put global force_resizable_activities 1; " +
                "settings put global freeform_window_management 1"
        ) { out -> toast(if (out.startsWith("ERR")) out else "Done. Reboot the phone once.") }
    }

    // ---------- App list ----------

    private fun loadApps() {
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val found = packageManager.queryIntentActivities(q, 0)
            .map { AppItem(it.loadLabel(packageManager).toString(), it.activityInfo.packageName) }
            .filter { it.pkg != packageName }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
        allApps.clear()
        allApps.addAll(found)
        pickOrder.clear()
        applyFilter("")
    }

    /** Shows only apps matching the query; selected apps stay selected while you search. */
    private fun applyFilter(query: String) {
        val q = query.trim().lowercase()
        apps.clear()
        apps.addAll(if (q.isEmpty()) allApps else allApps.filter { it.label.lowercase().contains(q) })
        adapter.notifyDataSetChanged()
        updatePickView()
    }

    private fun updatePickView() {
        val picked = currentPick()
        pickView.text = if (picked.isEmpty()) "Tap 2 to 4 apps. First tap = big active app."
        else picked.mapIndexed { i, a -> "${i + 1} ${a.label}" }.joinToString("   \u00B7   ")
        launchBtn.text = if (picked.size >= 2) "Launch ${picked.size} apps" else "Launch"
        launchBtn.alpha = if (picked.size >= 2) 1f else 0.5f
    }

    /** Selected apps in the order you tapped them. First = active (big) app. */
    private fun currentPick(): List<AppItem> =
        pickOrder.mapNotNull { p -> allApps.firstOrNull { it.pkg == p } }

    private fun iconFor(pkg: String): Drawable? = iconCache.getOrPut(pkg) {
        try { packageManager.getApplicationIcon(pkg) } catch (e: Exception) { null }
    }

    private class RowHolder(val root: LinearLayout, val icon: ImageView, val label: TextView, val badge: TextView)

    private inner class AppAdapter : BaseAdapter() {
        override fun getCount() = apps.size
        override fun getItem(position: Int): Any = apps[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val holder: RowHolder
            val view: View
            if (convertView == null) {
                holder = buildRow()
                view = holder.root
                view.tag = holder
            } else {
                view = convertView
                holder = convertView.tag as RowHolder
            }
            bindRow(holder, apps[position])
            return view
        }
    }

    private fun buildRow(): RowHolder {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(8), dp(14), dp(8))
        }
        val icon = ImageView(this)
        root.addView(icon, LinearLayout.LayoutParams(dp(38), dp(38)).apply { rightMargin = dp(12) })
        val label = TextView(this).apply {
            textSize = 15f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setTextColor(Ui.TEXT)
        }
        root.addView(label, LinearLayout.LayoutParams(0, -2, 1f))
        val badge = TextView(this).apply {
            gravity = Gravity.CENTER
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
        }
        root.addView(badge, LinearLayout.LayoutParams(dp(28), dp(28)))
        return RowHolder(root, icon, label, badge)
    }

    private fun bindRow(h: RowHolder, item: AppItem) {
        h.label.text = item.label
        h.icon.setImageDrawable(iconFor(item.pkg))
        val idx = pickOrder.indexOf(item.pkg)
        if (idx >= 0) {
            h.badge.text = (idx + 1).toString()
            h.badge.background =
                if (idx == 0) Ui.oval(Ui.ACCENT) else Ui.oval(Ui.SURFACE2, Ui.ACCENT, dp(2))
            h.root.background = Ui.ripple(Ui.rounded(Ui.SURFACE, dp(14)))
        } else {
            h.badge.text = ""
            h.badge.background = Ui.oval(Color.TRANSPARENT, Color.argb(90, 255, 255, 255), dp(2))
            h.root.background = Ui.ripple(Ui.rounded(Color.TRANSPARENT, dp(14)))
        }
    }

    private fun modeShort(m: LayoutMode) = when (m) {
        LayoutMode.BIG_STRIP -> "Big + strip"
        LayoutMode.GRID -> "Grid"
    }

    private fun setMode(m: LayoutMode) {
        selectedMode = m
        for ((k, v) in modeChips) {
            val sel = k == m
            Ui.setFill(v, if (sel) Ui.ACCENT else Color.TRANSPARENT, dp(10))
            v.setTextColor(if (sel) Color.WHITE else Ui.TEXT2)
            v.typeface = if (sel) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        }
    }

    private fun setLog(s: String) {
        logView.text = s.trim()
        logView.visibility = if (s.isBlank()) View.GONE else View.VISIBLE
    }

    // ---------- Launch ----------

    private fun launchSelected() {
        val picked = currentPick()
        if (picked.size < 2) { toast("Tap 2 to 4 apps (first tap = active)"); return }
        launchApps(picked, selectedMode)
    }

    private fun launchApps(
        picked: List<AppItem>,
        mode: LayoutMode,
        ratio: Float = WindowController.currentRatio()
    ) {
        if (!hasPermission()) { toast("Connect Shizuku first"); return }
        val area = ScreenArea.usable(this)
        setLog("Launching...")
        ensureDrawer()
        WindowController.launch(this, picked, mode, area, ratio)
    }

    // ---------- Favorites ----------

    private fun saveFavorite() {
        val picked = currentPick()
        if (picked.size < 2) { toast("Tap 2 to 4 apps first"); return }
        val mode = selectedMode
        val input = EditText(this).apply {
            hint = "e.g. Study, Game + video"
            setSingleLine()
        }
        AlertDialog.Builder(this)
            .setTitle("Save favorite")
            .setMessage(picked.joinToString(" + ") { it.label })
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val name = input.text.toString().trim()
                    .ifBlank { picked.joinToString("+") { it.label.take(6) } }
                Favorites.add(this, Favorite(name, mode, picked.map { it.pkg }, WindowController.currentRatio()))
                toast("Saved: $name")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showFavorites() {
        val favs = Favorites.load(this)
        if (favs.isEmpty()) { toast("No favorites yet. Tap apps, then \u2605 Save."); return }
        val names = favs.map { f ->
            val labels = f.pkgs.map { p -> allApps.firstOrNull { it.pkg == p }?.label ?: "(missing)" }
            "${f.name}\n${labels.joinToString(" + ")}" +
                (if (f.mode == LayoutMode.BIG_STRIP) "  \u00B7  ${(f.ratio * 100).toInt()}%" else "")
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Favorites")
            .setItems(names) { _, which -> launchFavorite(favs[which]) }
            .setNeutralButton("Delete...") { _, _ -> showDelete(favs) }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun showDelete(favs: List<Favorite>) {
        AlertDialog.Builder(this)
            .setTitle("Delete which favorite?")
            .setItems(favs.map { it.name }.toTypedArray()) { _, which ->
                Favorites.remove(this, favs[which].name)
                toast("Deleted ${favs[which].name}")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun launchFavorite(fav: Favorite) {
        val items = fav.pkgs.mapNotNull { p -> allApps.firstOrNull { it.pkg == p } }
        if (items.size < 2) { toast("Some apps in this favorite are not installed"); return }
        // Reflect the favorite in the list so you can see and tweak it.
        pickOrder.clear()
        pickOrder.addAll(items.map { it.pkg })
        adapter.notifyDataSetChanged()
        updatePickView()
        setMode(fav.mode)
        launchApps(items, fav.mode, fav.ratio)
    }

    // ---------- Swap drawer (starts automatically on launch) ----------

    private fun ensureDrawer() {
        sh("appops set $packageName SYSTEM_ALERT_WINDOW allow 2>&1") {
            if (Settings.canDrawOverlays(this)) {
                startService(Intent(this, ControlService::class.java))
            } else {
                toast("Swap drawer off: allow 'Display over other apps' for MultiWin in Settings")
            }
        }
    }

    // ---------- Quit ----------

    /** Removes the drawer, clears the session and ends MultiWin. Tiled apps keep running. */
    private fun quitMultiWin() {
        finishAndRemoveTask()
        WindowController.quitSelf(this)
    }

    /** Force stops every tiled app, then quits MultiWin. */
    private fun confirmCloseAllAndQuit() {
        AlertDialog.Builder(this)
            .setTitle("Close all & quit?")
            .setMessage("This force stops every tiled app, then quits MultiWin.")
            .setPositiveButton("Close all") { _, _ ->
                if (WindowController.entries().isNotEmpty() && !hasPermission()) {
                    toast("Shizuku not connected")
                } else {
                    finishAndRemoveTask()
                    WindowController.closeAllAndQuit(this)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------- Helpers ----------

    private fun dp(v: Int) = Ui.dp(this, v)

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
