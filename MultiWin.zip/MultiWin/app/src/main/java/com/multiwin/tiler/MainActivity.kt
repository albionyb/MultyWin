package com.multiwin.tiler

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())

    private val apps = mutableListOf<AppItem>()
    private lateinit var status: TextView
    private lateinit var logView: TextView
    private lateinit var list: ListView
    private lateinit var modeSpinner: Spinner

    private var shellInfo: String? = null
    private var checking = false

    private val permListener = Shizuku.OnRequestPermissionResultListener { _, _ ->
        shellInfo = null
        refresh()
    }
    private val binderListener = Shizuku.OnBinderReceivedListener {
        shellInfo = null
        refresh()
    }
    private val deadListener = Shizuku.OnBinderDeadListener {
        shellInfo = null
        refresh()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        val pad = (16 * d).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }

        status = TextView(this).apply { textSize = 14f }
        root.addView(status)
        logView = TextView(this).apply { textSize = 11f; maxLines = 8 }
        root.addView(logView)
        WindowController.onLog = { logView.text = it }

        root.addView(button("Grant Shizuku permission") { requestShizuku() })
        root.addView(button("Enable freeform windows (reboot after)") { enableFreeform() })
        root.addView(button("Show floating swap bar") { showBar() })
        val barRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        barRow.addView(button("Hide status bar (try)") { statusBar(true) }, LinearLayout.LayoutParams(0, -2, 1f))
        barRow.addView(button("Restore") { statusBar(false) }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(barRow)

        modeSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                LayoutMode.values().map { it.label }
            )
        }
        root.addView(modeSpinner)

        list = ListView(this).apply { choiceMode = ListView.CHOICE_MODE_MULTIPLE }
        list.onItemClickListener = AdapterView.OnItemClickListener { _, _, _, _ ->
            if (list.checkedItemCount > 4) {
                toast("Max 4 apps")
                for (i in 0 until list.count) if (list.isItemChecked(i)) { list.setItemChecked(i, false); break }
            }
        }
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))

        root.addView(button("Launch selected (first = active)") { launchSelected() })

        val swapRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (i in 1..3) {
            swapRow.addView(
                button("Swap ${i + 1}") { swap(i) },
                LinearLayout.LayoutParams(0, -2, 1f)
            )
        }
        root.addView(swapRow)
        setContentView(root)

        loadApps()

        Shizuku.addRequestPermissionResultListener(permListener)
        Shizuku.addBinderReceivedListenerSticky(binderListener)
        Shizuku.addBinderDeadListener(deadListener)
        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onDestroy() {
        WindowController.onLog = null
        Shizuku.removeRequestPermissionResultListener(permListener)
        Shizuku.removeBinderReceivedListener(binderListener)
        Shizuku.removeBinderDeadListener(deadListener)
        super.onDestroy()
    }

    // ---------- Shizuku ----------

    private fun hasPermission() = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) { false }

    private fun requestShizuku() {
        if (!Shizuku.pingBinder()) {
            toast("Start Shizuku first")
            return
        }
        if (hasPermission()) { shellInfo = null; refresh() } else Shizuku.requestPermission(1001)
    }

    private fun sh(cmd: String, done: (String) -> Unit = {}) {
        if (!hasPermission()) { toast("Shizuku not connected"); return }
        Thread {
            val out = ShizukuShell.exec(cmd)
            handler.post { done(out) }
        }.start()
    }

    private fun refresh() {
        val ping = try { Shizuku.pingBinder() } catch (e: Throwable) { false }
        when {
            !ping -> status.text = "Shizuku: not running"
            !hasPermission() -> status.text = "Shizuku: running, permission needed"
            shellInfo == null -> {
                status.text = "Shizuku: testing..."
                if (!checking) {
                    checking = true
                    sh("id") { out ->
                        checking = false
                        shellInfo = out.ifBlank { "no output" }
                        refresh()
                    }
                }
            }
            else -> status.text = "Shizuku: connected\n$shellInfo"
        }
    }

    private fun enableFreeform() {
        sh(
            "settings put global enable_freeform_support 1; " +
                "settings put global force_resizable_activities 1; " +
                "settings put global freeform_window_management 1"
        ) { out -> toast(if (out.startsWith("ERR")) out else "Done. Reboot the phone once.") }
    }

    // ---------- App list ----------

    private fun loadApps() {
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val found = packageManager.queryIntentActivities(q, 0)
            .map { AppItem(it.loadLabel(packageManager).toString(), it.activityInfo.packageName) }
            .filter { it.pkg != packageName }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
        apps.clear()
        apps.addAll(found)
        list.adapter = ArrayAdapter(
            this, android.R.layout.simple_list_item_multiple_choice, apps.map { it.label }
        )
    }

    // ---------- Launch, swap, extras ----------

    private fun launchSelected() {
        val picked = (0 until apps.size).filter { list.isItemChecked(it) }.map { apps[it] }
        if (picked.size < 2) { toast("Pick 2 to 4 apps"); return }
        if (!hasPermission()) { toast("Connect Shizuku first"); return }
        val m = resources.displayMetrics
        val mode = LayoutMode.values()[modeSpinner.selectedItemPosition]
        logView.text = "Launching..."
        WindowController.launch(this, picked, mode, m.widthPixels, m.heightPixels)
    }

    private fun swap(i: Int) = WindowController.swap(i)

    private fun showBar() {
        if (!hasPermission()) { toast("Connect Shizuku first"); return }
        sh("appops set $packageName SYSTEM_ALERT_WINDOW allow 2>&1") {
            if (Settings.canDrawOverlays(this)) {
                startService(Intent(this, ControlService::class.java))
                toast("Swap bar is on. Drag the handle to move it.")
            } else {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
                toast("Allow 'display over other apps', then tap again")
            }
        }
    }

    /** Works on some phones/Android versions only. Newer Android removed this setting. */
    private fun statusBar(hide: Boolean) {
        val value = if (hide) "immersive.status=*" else "null"
        sh("settings put global policy_control $value 2>&1") { out ->
            logView.text = if (out.isBlank()) "Status bar setting applied. Reopen the apps to see it." else out
        }
    }

    // ---------- Helpers ----------

    private fun button(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
