package com.multiwin.tiler

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())

    private val apps = mutableListOf<AppItem>()
    private val pickOrder = mutableListOf<String>() // tap order; first tapped = active app
    private lateinit var status: TextView
    private lateinit var logView: TextView
    private lateinit var list: ListView
    private lateinit var modeSpinner: Spinner

    private var shellInfo: String? = null
    private var checking = false

    private val permListener = Shizuku.OnRequestPermissionResultListener { _, _ ->
        shellInfo = null
        refresh()
    }
    private val binderListener = Shizuku.OnBinderReceivedListener {
        shellInfo = null
        refresh()
    }
    private val deadListener = Shizuku.OnBinderDeadListener {
        shellInfo = null
        refresh()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        val pad = (16 * d).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }

        status = TextView(this).apply { textSize = 14f }
        root.addView(status)
        logView = TextView(this).apply { textSize = 11f; maxLines = 8 }
        root.addView(logView)
        WindowController.onLog = { logView.text = it }

        root.addView(button("Grant Shizuku permission") { requestShizuku() })
        root.addView(button("Enable freeform windows (reboot after)") { enableFreeform() })

        val drawerRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        drawerRow.addView(button("Show swap drawer") { showBar() }, LinearLayout.LayoutParams(0, -2, 1f))
        drawerRow.addView(
            button("Hide drawer") { stopService(Intent(this, ControlService::class.java)) },
            LinearLayout.LayoutParams(0, -2, 1f)
        )
        root.addView(drawerRow)

        val barRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        barRow.addView(button("Hide status bar (try)") { statusBar(true) }, LinearLayout.LayoutParams(0, -2, 1f))
        barRow.addView(button("Restore") { statusBar(false) }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(barRow)

        modeSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                LayoutMode.values().map { it.label }
            )
        }
        root.addView(modeSpinner)

        list = ListView(this).apply { choiceMode = ListView.CHOICE_MODE_MULTIPLE }
        list.onItemClickListener = AdapterView.OnItemClickListener { _, _, pos, _ ->
            val pkg = apps[pos].pkg
            if (list.isItemChecked(pos)) {
                if (pickOrder.size >= 4) {
                    list.setItemChecked(pos, false)
                    toast("Max 4 apps")
                } else {
                    pickOrder.add(pkg)
                }
            } else {
                pickOrder.remove(pkg)
            }
        }
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))

        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        bottom.addView(button("Launch") { launchSelected() }, LinearLayout.LayoutParams(0, -2, 1f))
        bottom.addView(button("\u2605 Save") { saveFavorite() }, LinearLayout.LayoutParams(0, -2, 1f))
        bottom.addView(button("\u2605 Favorites") { showFavorites() }, LinearLayout.LayoutParams(0, -2, 1.3f))
        root.addView(bottom)
        setContentView(root)

        loadApps()

        Shizuku.addRequestPermissionResultListener(permListener)
        Shizuku.addBinderReceivedListenerSticky(binderListener)
        Shizuku.addBinderDeadListener(deadListener)
        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onDestroy() {
        WindowController.onLog = null
        Shizuku.removeRequestPermissionResultListener(permListener)
        Shizuku.removeBinderReceivedListener(binderListener)
        Shizuku.removeBinderDeadListener(deadListener)
        super.onDestroy()
    }

    // ---------- Shizuku ----------

    private fun hasPermission() = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) { false }

    private fun requestShizuku() {
        if (!Shizuku.pingBinder()) {
            toast("Start Shizuku first")
            return
        }
        if (hasPermission()) { shellInfo = null; refresh() } else Shizuku.requestPermission(1001)
    }

    private fun sh(cmd: String, done: (String) -> Unit = {}) {
        if (!hasPermission()) { toast("Shizuku not connected"); return }
        Thread {
            val out = ShizukuShell.exec(cmd)
            handler.post { done(out) }
        }.start()
    }

    private fun refresh() {
        val ping = try { Shizuku.pingBinder() } catch (e: Throwable) { false }
        when {
            !ping -> status.text = "Shizuku: not running"
            !hasPermission() -> status.text = "Shizuku: running, permission needed"
            shellInfo == null -> {
                status.text = "Shizuku: testing..."
                if (!checking) {
                    checking = true
                    sh("id") { out ->
                        checking = false
                        shellInfo = out.ifBlank { "no output" }
                        refresh()
                    }
                }
            }
            else -> status.text = "Shizuku: connected"
        }
    }

    private fun enableFreeform() {
        sh(
            "settings put global enable_freeform_support 1; " +
                "settings put global force_resizable_activities 1; " +
                "settings put global freeform_window_management 1"
        ) { out -> toast(if (out.startsWith("ERR")) out else "Done. Reboot the phone once.") }
    }

    // ---------- App list ----------

    private fun loadApps() {
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val found = packageManager.queryIntentActivities(q, 0)
            .map { AppItem(it.loadLabel(packageManager).toString(), it.activityInfo.packageName) }
            .filter { it.pkg != packageName }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
        apps.clear()
        apps.addAll(found)
        pickOrder.clear()
        list.adapter = ArrayAdapter(
            this, android.R.layout.simple_list_item_multiple_choice, apps.map { it.label }
        )
    }

    /** Selected apps in the order you tapped them. First = active (big) app. */
    private fun currentPick(): List<AppItem> =
        pickOrder.mapNotNull { p -> apps.firstOrNull { it.pkg == p } }

    // ---------- Launch ----------

    private fun launchSelected() {
        val picked = currentPick()
        if (picked.size < 2) { toast("Tap 2 to 4 apps (first tap = active)"); return }
        launchApps(picked, LayoutMode.values()[modeSpinner.selectedItemPosition])
    }

    private fun launchApps(picked: List<AppItem>, mode: LayoutMode) {
        if (!hasPermission()) { toast("Connect Shizuku first"); return }
        val area = ScreenArea.usable(this)
        logView.text = "Launching..."
        WindowController.launch(this, picked, mode, area)
    }

    // ---------- Favorites ----------

    private fun saveFavorite() {
        val picked = currentPick()
        if (picked.size < 2) { toast("Tap 2 to 4 apps first"); return }
        val mode = LayoutMode.values()[modeSpinner.selectedItemPosition]
        val input = EditText(this).apply {
            hint = "e.g. Study, Game + video"
            setSingleLine()
        }
        AlertDialog.Builder(this)
            .setTitle("Save favorite")
            .setMessage(picked.joinToString(" + ") { it.label })
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val name = input.text.toString().trim()
                    .ifBlank { picked.joinToString("+") { it.label.take(6) } }
                Favorites.add(this, Favorite(name, mode, picked.map { it.pkg }))
                toast("Saved: $name")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showFavorites() {
        val favs = Favorites.load(this)
        if (favs.isEmpty()) { toast("No favorites yet. Tap apps, then \u2605 Save."); return }
        val names = favs.map { f ->
            val labels = f.pkgs.map { p -> apps.firstOrNull { it.pkg == p }?.label ?: "(missing)" }
            "${f.name}\n${labels.joinToString(" + ")}"
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Favorites")
            .setItems(names) { _, which -> launchFavorite(favs[which]) }
            .setNeutralButton("Delete...") { _, _ -> showDelete(favs) }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun showDelete(favs: List<Favorite>) {
        AlertDialog.Builder(this)
            .setTitle("Delete which favorite?")
            .setItems(favs.map { it.name }.toTypedArray()) { _, which ->
                Favorites.remove(this, favs[which].name)
                toast("Deleted ${favs[which].name}")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun launchFavorite(fav: Favorite) {
        val items = fav.pkgs.mapNotNull { p -> apps.firstOrNull { it.pkg == p } }
        if (items.size < 2) { toast("Some apps in this favorite are not installed"); return }
        // Reflect the favorite in the list so you can see and tweak it.
        pickOrder.clear()
        pickOrder.addAll(items.map { it.pkg })
        for (i in apps.indices) list.setItemChecked(i, apps[i].pkg in pickOrder)
        modeSpinner.setSelection(fav.mode.ordinal)
        launchApps(items, fav.mode)
    }

    // ---------- Drawer and status bar ----------

    private fun showBar() {
        if (!hasPermission()) { toast("Connect Shizuku first"); return }
        sh("appops set $packageName SYSTEM_ALERT_WINDOW allow 2>&1") {
            if (Settings.canDrawOverlays(this)) {
                startService(Intent(this, ControlService::class.java))
                toast("Drawer on. Swipe the right-edge handle left.")
            } else {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
                toast("Allow 'display over other apps', then tap again")
            }
        }
    }

    /** Works on some phones/Android versions only. Newer Android removed this setting. */
    private fun statusBar(hide: Boolean) {
        val value = if (hide) "immersive.status=*" else "null"
        sh("settings put global policy_control $value 2>&1") { out ->
            logView.text = if (out.isBlank()) "Status bar setting applied. Reopen the apps to see it." else out
        }
    }

    // ---------- Helpers ----------

    private fun button(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
