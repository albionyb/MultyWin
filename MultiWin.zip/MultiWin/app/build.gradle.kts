plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Signing info comes from environment variables (set by the GitHub workflow
// or by you locally). Nothing secret is stored in this file.
val keystorePath: String? = System.getenv("KEYSTORE_PATH")
val hasReleaseKey = keystorePath != null && file(keystorePath).exists()

android {
    namespace = "com.multiwin.tiler"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.multiwin.tiler"
        minSdk = 29
        targetSdk = 34
        versionCode = 3
        versionName = "0.03"
    }

    signingConfigs {
        if (hasReleaseKey) {
            create("release") {
                storeFile = file(keystorePath!!)
                storePassword = System.getenv("KEYSTORE_PASSWORD")
                keyAlias = System.getenv("KEY_ALIAS")
                keyPassword = System.getenv("KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            isDebuggable = false
            // Shizuku is called through reflection, so keep code shrinking off.
            isMinifyEnabled = false
            isShrinkResources = false
            if (hasReleaseKey) signingConfig = signingConfigs.getByName("release")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    lint {
        // Do not let lint warnings break the release build.
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")
}
