# MultiWin

Run 3-4 apps at once on one screen: one big **active** app plus small **background** tiles. Uses Android freeform windows, with Shizuku to resize and swap windows.

## Phone setup (once)
1. Install Shizuku and start it (Wireless debugging).
2. Install MultiWin, open it, tap **Grant Shizuku permission**.
3. Tap **Enable freeform windows**, then reboot.

## Use
Pick 2-4 apps (first = active), choose a layout, tap **Launch**. Use **Swap 2/3/4** to trade a tile with the active pane.

## Build
Push to GitHub. Actions builds the APK: Actions tab > latest run > Artifacts > MultiWin-debug-apk.

## Roadmap
- v0.2 floating swap bubble (SYSTEM_ALERT_WINDOW)
- v0.3 saved layout presets
- v0.4 per-device resize fixes
