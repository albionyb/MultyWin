# MultiWin

Run 3-4 apps at once on one screen: one big **active** app plus small **background** tiles. Uses Android freeform windows, with Shizuku to resize and swap windows.

## Phone setup (once)
1. Install Shizuku and start it (Wireless debugging).
2. Install MultiWin, open it, tap **Grant Shizuku permission**.
3. Tap **Enable freeform windows**, then reboot.

## Use
Pick 2-4 apps (first = active), choose a layout, tap **Launch**. Use **Swap 2/3/4** to trade a tile with the active pane.

## Build & release (GitHub, straight from the zip)
Repo layout: just `MultiWin.zip` + `.github/workflows/build.yml`. Do not unpack the zip.
Push to `main` -> Actions unzips it, builds a signed release APK and publishes a
GitHub Release `v<versionName>` (see `versionName` in `app/build.gradle.kts`) with the APK attached.

Signing: add secrets `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`.
To release a new version: bump `versionCode` and `versionName`, re-zip, push.

## Roadmap
- v0.2 floating swap bubble (SYSTEM_ALERT_WINDOW)
- v0.3 saved layout presets
- v0.4 per-device resize fixes
