# MultiWin

Run 3-4 apps at once on one screen: one big **active** app plus small **background** tiles. Uses Android freeform windows, with Shizuku to resize and swap windows.

## Phone setup (once)
1. Install Shizuku and start it (Wireless debugging).
2. Install MultiWin, open it, tap **Grant Shizuku permission**.
3. Tap **Enable freeform windows**, then reboot.

## Use
Pick 2-4 apps (first = active), choose a layout, tap **Launch**. An edge drawer (thin handle on the right edge) appears: swipe it left or tap it to open the list; drag it up/down to move it.

Drawer, per app:
- **Name** (tap): swap that app with the active one. The active app is marked with a play triangle.
- **Restore**: relaunches the app, puts it back in a tile and re-tiles everything. Use it on a stopped app, or on one whose window got lost or minimized.
- **Stop**: force stops the app (through Shizuku), removes it from the layout and re-tiles the rest so no blank area is left. If it was the active app, the next app becomes active. A stopped app stays in the list as "(stopped)" so you can Restore it. With no running app left the drawer shows "No apps".

Drawer, bottom:
- **Hide drawer**: removes the drawer only.
- **Quit MultiWin**: removes the drawer, clears the session and fully ends MultiWin, like a force stop. Tiled apps keep running.
- **Close all & quit**: force stops every tiled app, then quits MultiWin.

**Quit MultiWin** and **Close all & quit** are also on the main screen (Close all asks for confirmation there).

## Build & release (GitHub, straight from the zip)
Repo layout: just `MultiWin.zip` + `.github/workflows/build.yml`. Do not unpack the zip.
Push to `main` -> Actions unzips it, builds a signed release APK and publishes a
GitHub Release `v<versionName>` (see `versionName` in `app/build.gradle.kts`) with the APK attached.

Signing: add secrets `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`.
To release a new version: bump `versionCode` and `versionName`, re-zip, push.

## Changelog
- **0.02** (versionCode 2): per-app Stop and Restore, Quit MultiWin, Close all & quit, new drawer layout.
- **0.01**: first release.

## Roadmap
- Per-device resize fixes
